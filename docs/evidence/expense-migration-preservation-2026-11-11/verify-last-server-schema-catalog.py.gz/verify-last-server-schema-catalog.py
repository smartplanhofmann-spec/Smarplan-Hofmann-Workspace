import json,subprocess,sys,tarfile,tempfile
from pathlib import Path
root=Path('/workspace/Smarplan-Hofmann-Workspace');commits=['a93cb4d02eab610e5f2a8b07fbd1ee51ae99c3e5','4bb5071891344a38f640d8ae43ec240c1f95e61e'];catalogs=[]
with tempfile.TemporaryDirectory(prefix='synthetic-schema-contract-archives-') as directory:
 for commit in commits:
  dest=Path(directory)/commit;dest.mkdir();archive=dest/'source.tar'
  subprocess.run(['git','-C',str(root),'archive','--format=tar','--output',str(archive),commit,'backend'],check=True,capture_output=True)
  with tarfile.open(archive) as source:source.extractall(dest,filter='data')
  code='''import json,sqlite3,sys
from types import SimpleNamespace
sys.path.insert(0,sys.argv[1])
from business_schema import registry,_definition,_control_checksum
memory=sqlite3.connect(':memory:')
try:
 contracts={spec.name:dict(version=spec.version,sqlite=_definition(SimpleNamespace(db=memory),spec)[2],postgresql=_definition(SimpleNamespace(db=object()),spec)[2]) for spec in registry()}
 print(json.dumps(dict(control_checksum=_control_checksum(),contracts=contracts),sort_keys=True))
finally:memory.close()
'''
  catalogs.append(json.loads(subprocess.check_output([sys.executable,'-I','-B','-c',code,str(dest/'backend')],cwd=dest,text=True)))
assert catalogs[0]['control_checksum']==catalogs[1]['control_checksum']
for name,value in catalogs[0]['contracts'].items():assert catalogs[1]['contracts'][name]==value,name
print(json.dumps(dict(previous_source=commits[0],corrected_source=commits[1],modules=len(catalogs[0]['contracts']),dialects=2,control_unchanged=True,all_contracts_unchanged=True,old_modules=len(catalogs[0]['contracts']),added_modules=sorted(set(catalogs[1]['contracts'])-set(catalogs[0]['contracts'])),catalog=catalogs[1]),indent=2))
