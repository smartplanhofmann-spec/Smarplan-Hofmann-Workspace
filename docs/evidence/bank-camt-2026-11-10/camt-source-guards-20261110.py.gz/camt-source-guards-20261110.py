import hashlib,json,subprocess,re
from pathlib import Path
r=Path('/workspace/Smarplan-Hofmann-Workspace')
base='abcc3510f4d913b1d4e57c30fd2e5283bce2156b'
files=subprocess.check_output(['git','ls-tree','-r','--name-only',base,'backend'],cwd=r,text=True).splitlines()
modules=[p for p in files if Path(p).name.startswith('payroll_') and p.endswith('.py')]
for path in modules:
 assert (r/path).read_bytes()==subprocess.check_output(['git','show',base+':'+path],cwd=r),path
original=(r/'CRM_ERP_Gesamtziel.txt').read_bytes();assert len(original)==23863
assert hashlib.sha256(original).hexdigest()=='a4dea28f6de4afd3e36d1549441aad91ce16dad374f56097979cc2d79b07fbf5'
text=(r/'docs/CRM_ERP_ANFORDERUNGEN.md').read_text();rows=[l for l in text.splitlines() if l.startswith('| R') and re.fullmatch(r'R\d{2}\.\d{2}',l.split('|')[1].strip())]
assert len(rows)==62
assert all(len(l.split('|'))==6 for l in rows),[l[:70] for l in rows if len(l.split('|'))!=6]
print(json.dumps(dict(historical_payroll_modules_unchanged=len(modules),base=base,goal_bytes=len(original),goal_sha256=hashlib.sha256(original).hexdigest(),requirements_rows=len(rows))))
