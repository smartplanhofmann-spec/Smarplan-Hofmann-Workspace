SMARTPLAN – JAHRESPRÜFSTAND MIT ORIGINALEN, VERSION 1

report.json und postings.csv sind der ursprünglich bestätigte EÜR-Prüfstand.
journal.json enthält die zugehörigen Entscheidungen und ursprünglichen Befehle.
proofs.json verbindet die Quellen mit den unveränderten Dateien in originals/.
Andere Journalpositionen sind nur durch Sequenz und Hash gebunden. Notwendige
frühere Belege können außerhalb des Berichtsjahres liegen.

Dies ist ein eigenes Prüf-/Übergabeformat, kein DATEV-Importformat, keine
Steuererklärung, keine elektronische Signatur und keine fachliche Steuerfreigabe.
Offene Fragen des ursprünglichen Berichts bleiben offen. Öffentliche Lohn- und
Reisegeldprojektionen enthalten ausdrücklich keine privaten Personaloriginale.
Ihre private Berechnung kann mit diesem Finanzpaket nicht geprüft werden.

Das Archiv enthält finanzielle Originale und ist nicht verschlüsselt. Es wurde
an niemanden gesendet. Nur berechtigten Empfängern in geschützter Ablage geben.
Zuerst den ZIPhash mit dem separat in Smartplan angezeigten Hash vergleichen.
Den Prüfer aus einer vertrauenswürdigen Installation verwenden; ein fremdes
Archivskript nicht ungeprüft starten. Der beigefügte Prüfer ist eigenständig:
python verify_year_package.py DATEI.zip --sha256 SEPARAT_BESTAETIGTER_ZIPHASH
Es werden keine Archivdateien extrahiert oder ausgeführt und keine Dienste
kontaktiert. Hashkonsistenz allein beweist keine externe Herkunft.
