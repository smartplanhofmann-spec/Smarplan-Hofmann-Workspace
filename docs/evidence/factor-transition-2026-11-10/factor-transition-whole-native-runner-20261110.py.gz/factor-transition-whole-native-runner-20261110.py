from datetime import datetime, timezone
import json, os, subprocess, time
from pathlib import Path

root=Path('/workspace/smartplan-factor-transition-20261110')
env=os.environ.copy()
env['PATH']='/workspace/toolchains/clang-19/bin:'+env['PATH']
env['PUB_CACHE']='/workspace/toolchains/pub-cache'
record=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    worktree=str(root),started_utc=datetime.now(timezone.utc).isoformat(),
    command=['/workspace/toolchains/flutter/bin/flutter','test','--no-pub','--reporter=json'])
status=Path('/tmp/factor-transition-whole-native-first-status-20261110.json')
status.write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic()
try:
    with Path('/tmp/factor-transition-whole-native-first-20261110.jsonl').open('w')as output,Path('/tmp/factor-transition-whole-native-first-stderr-20261110.txt').open('w')as errors:
        process=subprocess.run(record['command'],cwd=root/'app',env=env,stdout=output,stderr=errors)
    record.update(exit_code=process.returncode,seconds=time.monotonic()-start,
        completed_utc=datetime.now(timezone.utc).isoformat())
finally:
    status.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
raise SystemExit(record.get('exit_code',1))
