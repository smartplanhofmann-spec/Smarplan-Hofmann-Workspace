import json
from pathlib import Path

starts={};done={};terminal=[];diagnostic_arrays=blank=0;errors=[];partial=0
for line in Path('/tmp/factor-transition-whole-native-first-20261110.jsonl').read_text().splitlines():
    if not line.strip():blank+=1;continue
    try:event=json.loads(line)
    except json.JSONDecodeError:partial+=1;continue
    if isinstance(event,list):diagnostic_arrays+=1;continue
    if event.get('type')=='testStart':starts[event['test']['id']]=event['test']
    elif event.get('type')=='testDone':
        assert event['testID']not in done,'Duplicate completion event'
        done[event['testID']]=event
    elif event.get('type')=='done':terminal.append(event)
    elif event.get('type')=='error':errors.append(event)
visible=[event for event in done.values()if event.get('hidden')is not True]
result=dict(visible_completed=len(visible),passed=sum(e.get('result')=='success'for e in visible),
    failed=sum(e.get('result')!='success'for e in visible),skipped=sum(e.get('skipped')is True for e in visible),
    hidden_loader_entries_excluded=sum(e.get('hidden')is True for e in done.values()),
    terminal=terminal[-1:]if terminal else [],blank_lines=blank,diagnostic_arrays=diagnostic_arrays,
    partial_lines=partial,errors=errors,
    currently_running=[test['name']for key,test in starts.items()if key not in done and not test['name'].startswith('loading ')])
print(json.dumps(result,ensure_ascii=False,indent=2))
