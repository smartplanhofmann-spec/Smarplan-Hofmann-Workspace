import json,os,sqlite3,subprocess,sys,tarfile,tempfile
from pathlib import Path
root=Path('/workspace/Smarplan-Hofmann-Workspace')
base='ab6b61535a35f8306bbf04ebe6557acdb2ac3f41'
with tempfile.TemporaryDirectory(prefix='synthetic-expense-schema-upgrade-') as directory:
 d=Path(directory);archive=d/'old.tar';old=d/'old';old.mkdir();database=d/'preserved.db';receipt=d/'receipt.json'
 subprocess.run(['git','-C',str(root),'archive','--format=tar','--output',str(archive),base,'backend'],check=True)
 with tarfile.open(archive) as source:source.extractall(old,filter='data')
 code='''import json,sqlite3,sys
sys.path.insert(0,sys.argv[1])
from test_business_personnel_workflow import PersonnelWorkflowTests,rid
f=PersonnelWorkflowTests('runTest');f.setUp()
try:
 expense=f.approved_expense();body=dict(request_id=rid(),revision=expense['revision'],amount_minor=4987,confirmed=True,paid_on='2026-10-25',payment_reference='SYNTHETIC-OLD-PAID')
 result=f.hr.expense_action(f.owner,expense['id'],'reimburse',body)
 from business_schema import registry,_definition
 from types import SimpleNamespace
 spec=next(s for s in registry() if s.name=='business_personnel_workflow')
 memory=sqlite3.connect(':memory:')
 baseline=dict(source_commit='ab6b61535a35f8306bbf04ebe6557acdb2ac3f41',module=spec.name,version=spec.version,sqlite=_definition(SimpleNamespace(db=memory),spec)[2],postgresql=_definition(SimpleNamespace(db=object()),spec)[2])
 print(json.dumps(baseline));memory.close()
 target=sqlite3.connect(sys.argv[2]);f.office.db.backup(target);target.close()
 from pathlib import Path
 Path(sys.argv[3]).write_text(json.dumps(dict(actor=f.owner,id=expense['id'],body=body,result=result)))
finally:f.doCleanups()
'''
 subprocess.run([sys.executable,'-I','-B','-c',code,str(old/'backend'),str(database),str(receipt)],check=True,cwd=d)
 sys.path.insert(0,str(root/'backend'))
 from core import Office
 from business_schema import ensure_schema
 from business_personnel_workflow import PersonnelWorkflow
 office=Office(database)
 try:
  ensure_schema(office);value=json.loads(receipt.read_text())
  assert PersonnelWorkflow(office).expense_action(value['actor'],value['id'],'reimburse',value['body'])==value['result']
  print(json.dumps(dict(upgrade_from=base,original_payment_receipt_preserved=True,passed=True)))
 finally:office.db.close()
