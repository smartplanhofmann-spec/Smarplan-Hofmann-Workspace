@echo off
setlocal
title Smartplan Office - Python-Abhaengigkeiten

echo Pruefe Python 3.12 fuer Windows, 64 Bit...
py -3.12 -c "import sys; assert sys.version_info[:2] == (3, 12) and sys.maxsize > 2**32, 'Python 3.12 (64 Bit) erforderlich'"
if errorlevel 1 goto error

if not defined LOCALAPPDATA goto error
set "smartplan_python=%LOCALAPPDATA%\SmartplanOffice\.venv\Scripts\python.exe"
if not exist "%smartplan_python%" (
  py -3.12 -m venv "%LOCALAPPDATA%\SmartplanOffice\.venv"
  if errorlevel 1 goto error
)
"%smartplan_python%" -c "import sys; assert sys.version_info[:2] == (3, 12) and sys.maxsize > 2**32, 'Vorhandene Umgebung muss Python 3.12 (64 Bit) verwenden'"
if errorlevel 1 goto error

echo.
echo Installiere lokale Pakete mit SHA-256-Pruefung, ohne Internetzugriff...
"%smartplan_python%" -m pip install --disable-pip-version-check --no-cache-dir --no-index --find-links "%~dp0wheels" --require-hashes -r "%~dp0requirements-windows.lock"
if errorlevel 1 goto error

"%smartplan_python%" -m pip check
if errorlevel 1 goto error

echo.
echo Pruefe PDF-Erzeugung und Verschluesselung...
"%smartplan_python%" -c "import io; from reportlab.pdfgen.canvas import Canvas; from cryptography.fernet import Fernet; data=io.BytesIO(); pdf=Canvas(data); pdf.drawString(40,40,'Smartplan Office'); pdf.save(); assert data.getvalue().startswith(b'%%PDF'); vault=Fernet(Fernet.generate_key()); assert vault.decrypt(vault.encrypt(b'self-test'))==b'self-test'; print('PDF und Verschluesselung: OK')"
if errorlevel 1 goto error

echo.
echo FERTIG: Smartplan-Abhaengigkeiten sind installiert und geprueft.
echo Schicken Sie ein Bildschirmfoto dieses Fensters fuer den naechsten Schritt.
pause
exit /b 0

:error
echo.
echo Installation oder Pruefung fehlgeschlagen. Bitte ein Bildschirmfoto senden.
pause
exit /b 1
