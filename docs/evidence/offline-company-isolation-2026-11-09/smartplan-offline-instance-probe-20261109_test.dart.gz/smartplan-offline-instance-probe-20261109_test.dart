import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:smartplan_office/offline_plans.dart';
import '/workspace/Smarplan-Hofmann-Workspace/app/test/offline_plans_test.dart'
    show PlanServer, TestDevice, idle;

class CapturingServer extends PlanServer {
  final bodies = <Map<String, dynamic>>[];
  @override
  Future<dynamic> call(String path, [Map<String, dynamic>? body]) {
    if (path.contains('/plans') && body != null) {
      bodies.add(Map<String, dynamic>.from(body));
    }
    return super.call(path, body);
  }
}

void main() {
  test('READ-ONLY AUDIT: same server and account lets company B see and receive A pending plan', () async {
    final folder = await Directory.systemTemp.createTemp('offline-instance-probe-');
    final device = TestDevice(folder);
    final first = CapturingServer()..token = 'synthetic-A-online-session';
    final second = CapturingServer()..token = 'synthetic-B-online-session';
    const user = {'id': 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'role': 'owner'};
    const projectId = 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb';
    final now = DateTime.utc(2026, 10, 26);
    OfflinePlans? current;
    try {
      current = OfflinePlans(api:first, transport:first, device:device, clock:() => now);
      await current.login(user, [{'id':projectId,'name':'Company A project'}]);
      await idle(current);
      first.online = false;
      final local = await current.save(projectId, {'title':'CONFIDENTIAL COMPANY A PLAN','walls':[]});
      await idle(current);
      expect(current.pending,1);
      await current.leave();
      current.dispose();

      second.hold = Completer<void>();
      current = OfflinePlans(api:second, transport:second, device:device, clock:() => now);
      await current.login(user, [{'id':projectId,'name':'Company B project'}]);
      await second.started.future.timeout(const Duration(seconds:10));
      expect(current.projects.single['name'],'Company B project');
      expect(current.get(local['local_id'])['title'],'CONFIDENTIAL COMPANY A PLAN');
      expect(second.bodies.single['title'],'CONFIDENTIAL COMPANY A PLAN');
      second.hold!.complete();
      await idle(current);
      expect(second.plans.values.single['title'],'CONFIDENTIAL COMPANY A PLAN');
      expect(current.pending,0);
      print(jsonEncode({
        'same_scope': '${first.base}|${first.version}' == '${second.base}|${second.version}',
        'new_project_label': current.projects.single['name'],
        'old_company_plan_visible': current.get(local['local_id'])['title']=='CONFIDENTIAL COMPANY A PLAN',
        'old_company_plan_sent_to_new_transport':second.plans.values.single['title']=='CONFIDENTIAL COMPANY A PLAN',
        'pending_after_new_company_ack':current.pending,
        'shared_encrypted_store_count':(await folder.list().toList()).length,
      }));
    } finally {
      if(second.hold?.isCompleted == false) second.hold!.complete();
      if(current != null) { await idle(current); current.dispose(); }
      first.dispose(); second.dispose();
      await folder.delete(recursive:true);
    }
  });
}
