"""Synthetic copied legacy device session across separately bound companies.

No network, actual credentials, existing data or repository files are used.
The common seed intentionally gives both companies identical user credentials
and object IDs, while each company keeps its own instance/storage/key binding.
"""
from pathlib import Path
import json
import sqlite3
import tempfile
import time
import uuid

from cryptography.fernet import Fernet
from core import Office
from online.auth import totp
from online.instance import bind
from online.storage import Storage
from online.web import create_app
from online.test_instance_isolation import MFA_SCHEMA


with tempfile.TemporaryDirectory(prefix='offline-v1-get-copy-audit-') as temporary:
    root = Path(temporary)
    seed = Office(root / 'seed.db')
    seed.db.executescript(MFA_SCHEMA)
    owner = {'id': seed.add_user('owner@example.test', 'Synthetic-owner-password-123', 'owner'), 'role': 'owner'}
    project = seed.add_project(owner, 'Company A private project', 'Company A customer')
    for name in ('a', 'b'):
        target = sqlite3.connect(root / (name + '.db'))
        seed.db.backup(target)
        target.close()
    seed.db.close()

    companies = []
    for name in ('a', 'b'):
        office = Office(root / (name + '.db'))
        if name == 'b':
            with office.db:
                office.db.execute('UPDATE projects SET name=? WHERE id=?', ('Company B private project', project))
        instance = uuid.uuid4().hex
        key = Fernet.generate_key()
        host = 'same.example.test'
        storage = Storage(office, key, host, config={'server': {'path': str(root / (name + '-storage'))}})
        bind(office, instance, host, key, storage)
        client = create_app(office=office, key=key, host=host, storage=storage, instance_id=instance).test_client()

        def call(path, body=None, token=None):
            return client.open('/api/v1' + path, method='GET' if body is None else 'POST',
                base_url='https://' + host, json=body,
                headers={'Authorization': 'Bearer ' + token} if token else {})

        pending = call('/login', {'email': 'owner@example.test', 'password': 'Synthetic-owner-password-123'}).json
        token = call('/login/verify', {'challenge': pending['challenge'],
            'code': totp(pending['enrollment']['secret'], int(time.time() // 30))}).json['token']
        grant = call('/offline/access', {}, token).json['token']
        companies.append((office, client, grant, instance, key))

    a, b = companies

    def get_b(path, token):
        return b[1].get('/api/v1' + path, base_url='https://same.example.test',
            headers={'Authorization': 'Bearer ' + token})

    before = get_b('/projects', a[2])
    source = a[0].db.execute('SELECT token,user_id,expiry,credential FROM plan_sessions').fetchone()
    assert source is not None
    with b[0].db:
        b[0].db.execute('INSERT INTO plan_sessions(token,user_id,expiry,credential) VALUES(?,?,?,?)', tuple(source))
    # Startup still validates B's own company/storage/key binding after the
    # copied session is present; no identity guard has been disabled or edited.
    b_client_after_copy = create_app(office=b[0], key=b[4], host='same.example.test',
        storage=Storage(b[0], b[4], 'same.example.test', config={'server': {'path': str(root / 'b-storage')}}),
        instance_id=b[3]).test_client()
    after = b_client_after_copy.get('/api/v1/projects', base_url='https://same.example.test',
        headers={'Authorization': 'Bearer ' + a[2]})
    record = next(item for item in after.json if item['id'] == project)
    result = {
        'distinct_operator_bound_instances': a[3] != b[3],
        'distinct_server_keys': a[4] != b[4],
        'same_user_id': source['user_id'] == owner['id'],
        'old_A_token_at_B_before_copy': before.status_code,
        'B_http_startup_after_copy': 'passed_own_instance_binding',
        'old_A_token_at_B_after_copy': after.status_code,
        'B_private_project_name_returned': record['name'],
        'copied_tables': ['plan_sessions'],
        'user_credentials': 'identical_synthetic_seed_before_mfa',
        'instance_identity_table_copied': False,
    }
    assert result['distinct_operator_bound_instances'] and result['distinct_server_keys']
    assert (before.status_code, after.status_code) == (401, 200), result
    assert record['name'] == 'Company B private project'
    print(json.dumps(result, indent=2))
    for office, _, _, _, _ in companies:
        office.db.close()
