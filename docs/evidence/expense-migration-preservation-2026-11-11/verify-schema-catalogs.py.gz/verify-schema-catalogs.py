import json,subprocess,sys,tarfile,tempfile
from pathlib import Path
root=Path('/workspace/Smarplan-Hofmann-Workspace');commits=['ab6b61535a35f8306bbf04ebe6557acdb2ac3f41','4bb5071891344a38f640d8ae43ec240c1f95e61e'];catalogs=[]
with tempfile.TemporaryDirectory(prefix='synthetic-schema-contract-archives-') as directory:
 for commit in commits:
  dest=Path(directory)/commit;dest.mkdir();archive=dest/'source.tar'
  subprocess.run(['git','-C',str(root),'archive','--format=tar','--output',str(archive),commit,'backend'],check=True,capture_output=True)
  with tarfile.open(archive) as source:source.extractall(dest,filter='data')
  code='''import json,sqlite3,sys
from types import SimpleNamespace
sys.path.insert(0,sys.argv[1])
from business_schema import registry,_definition,_control_checksum
memory=sqlite3.connect(':memory:')
try:
 contracts={spec.name:dict(version=spec.version,sqlite=_definition(SimpleNamespace(db=memory),spec)[2],postgresql=_definition(SimpleNamespace(db=object()),spec)[2]) for spec in registry()}
 print(json.dumps(dict(control_checksum=_control_checksum(),contracts=contracts),sort_keys=True))
finally:memory.close()
'''
  catalogs.append(json.loads(subprocess.check_output([sys.executable,'-I','-B','-c',code,str(dest/'backend')],cwd=dest,text=True)))
assert catalogs[0]==catalogs[1]
print(json.dumps(dict(previous_source=commits[0],corrected_source=commits[1],modules=len(catalogs[0]['contracts']),dialects=2,control_unchanged=True,all_contracts_unchanged=True,catalog=catalogs[1]),indent=2))
