import json,os,subprocess,sys,time
from pathlib import Path

name='smartplan-expense-index-pg-20261111'
label='smartplan.expense-index.synthetic=20261111'
root=Path('/workspace/Smarplan-Hofmann-Workspace')
destination=Path('/tmp/smartplan-expense-index-review-20261111')
attempt=sys.argv[1] if len(sys.argv)>1 else 'first'
def run(*args,**kw):return subprocess.run(args,check=True,text=True,capture_output=True,**kw).stdout.strip()
container=run('docker','--host=unix:///var/run/docker.sock','run','--detach','--name',name,'--label',label,'--tmpfs','/var/lib/postgresql/data:rw,size=768m',
    '--publish','127.0.0.1::5432','--env','POSTGRES_DB=smartplan_check','--env','POSTGRES_PASSWORD=synthetic-expense-local-only','postgres:16-bookworm')
result=dict(container_id=container,name=name,synthetic=True,cleanup_verified=False)
code=1
try:
    info=json.loads(run('docker','--host=unix:///var/run/docker.sock','inspect',container))[0]
    assert info['Name']=='/'+name and info['Config']['Labels'].get('smartplan.expense-index.synthetic')=='20261111'
    ports=info['NetworkSettings']['Ports']['5432/tcp'];assert len(ports)==1 and ports[0]['HostIp']=='127.0.0.1'
    port=ports[0]['HostPort'];result['loopback_port']=port
    for _ in range(100):
        ready=subprocess.run(['docker','--host=unix:///var/run/docker.sock','exec',container,'pg_isready','-U','postgres','-d','smartplan_check'],capture_output=True).returncode==0
        if ready:break
        time.sleep(.2)
    if not ready:raise RuntimeError('Own disposable PostgreSQL did not become ready')
    env=dict(os.environ,SMARTPLAN_TEST_DSN=f'host=127.0.0.1 port={port} dbname=smartplan_check user=postgres password=synthetic-expense-local-only',
        PYTHONPATH='.:backend:backend/business_tests:backend/online:scripts:/tmp/smartplan-expense-index-review-20261111')
    tool_dir=destination/'own-pg-tools';tool_dir.mkdir(exist_ok=True)
    tool_code='''#!'''+sys.executable+'''
import json,os,sys,subprocess
from psycopg.conninfo import conninfo_to_dict,make_conninfo
args=sys.argv[1:];position=args.index('--dbname')+1
p=conninfo_to_dict(args[position]);container=os.environ['SMARTPLAN_RV_PG_CONTAINER'];port=os.environ['SMARTPLAN_RV_PG_PORT']
assert p.get('host')=='127.0.0.1' and p.get('port')==port and p['dbname'] in ('smartplan_check','smartplan_release_check','smartplan_restore_check')
info=json.loads(subprocess.check_output(['docker','--host=unix:///var/run/docker.sock','inspect',container]))[0]
assert info['Id']==container and info['Config']['Labels']['smartplan.expense-index.synthetic']=='20261111'
assert info['NetworkSettings']['Ports']['5432/tcp']==[{'HostIp':'127.0.0.1','HostPort':port}]
args[position]=make_conninfo(args[position],port=5432)
tool=os.path.basename(sys.argv[0]);assert tool in ('pg_dump','pg_restore')
os.execvp('docker',['docker','--host=unix:///var/run/docker.sock','exec','-i',container,tool,*args])
'''
    for name_tool in ('pg_dump','pg_restore'):
        executable=tool_dir/name_tool;executable.write_text(tool_code);executable.chmod(0o700)
    env.update(PATH=str(tool_dir)+os.pathsep+env.get('PATH',''),SMARTPLAN_RV_PG_CONTAINER=container,SMARTPLAN_RV_PG_PORT=port)
    with (destination/('postgres-'+attempt+'.txt')).open('w') as output:
        modules=['test_old_personnel_upgrade_pg','online.test_business_expense_originals_pg','online.test_business_personnel_workflow_pg']
        test=subprocess.run([sys.executable,'-m','unittest','-v',*modules],cwd=root,env=env,
            stdout=output,stderr=subprocess.STDOUT,timeout=600)
    code=test.returncode;result['test_exit_code']=code
finally:
    original=json.loads(run('docker','--host=unix:///var/run/docker.sock','inspect',container))[0]
    assert original['Id']==container and original['Name']=='/'+name and original['Config']['Labels'].get('smartplan.expense-index.synthetic')=='20261111'
    run('docker','--host=unix:///var/run/docker.sock','rm','--force',container)
    result['cleanup_verified']=not run('docker','--host=unix:///var/run/docker.sock','ps','--all','--quiet','--filter','id='+container)
    (destination/('postgres-'+attempt+'-environment.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
sys.exit(code)
