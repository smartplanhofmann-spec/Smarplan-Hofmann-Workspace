from pathlib import Path
p=Path('/tmp/smartplan-expense-index-review-20261111/reproduce-upgrade.py');s=p.read_text().replace("s.name=='personnel_workflow'","s.name=='business_personnel_workflow'");p.write_text(s)
