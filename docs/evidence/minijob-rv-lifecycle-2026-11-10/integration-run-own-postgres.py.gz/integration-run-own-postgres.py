import json,os,subprocess,sys,time
from pathlib import Path

name='smartplan-rv-lifecycle-pg-20261110'
label='smartplan.rv-lifecycle.synthetic=20261110'
root=Path('/workspace/smartplan-minijob-rv-20261110')
destination=Path('/tmp/smartplan-minijob-rv-work-20261110')
attempt=sys.argv[1] if len(sys.argv)>1 else 'first'
def run(*args,**kw):return subprocess.run(args,check=True,text=True,capture_output=True,**kw).stdout.strip()
container=run('docker','run','--detach','--name',name,'--label',label,'--tmpfs','/var/lib/postgresql/data:rw,size=768m',
    '--publish','127.0.0.1::5432','--env','POSTGRES_DB=smartplan_check','--env','POSTGRES_PASSWORD=synthetic-rv-local-only','postgres:16-bookworm')
result=dict(container_id=container,name=name,synthetic=True,cleanup_verified=False)
code=1
try:
    info=json.loads(run('docker','inspect',container))[0]
    assert info['Name']=='/'+name and info['Config']['Labels'].get('smartplan.rv-lifecycle.synthetic')=='20261110'
    ports=info['NetworkSettings']['Ports']['5432/tcp'];assert len(ports)==1 and ports[0]['HostIp']=='127.0.0.1'
    port=ports[0]['HostPort'];result['loopback_port']=port
    for _ in range(100):
        ready=subprocess.run(['docker','exec',container,'pg_isready','-U','postgres','-d','smartplan_check'],capture_output=True).returncode==0
        if ready:break
        time.sleep(.2)
    if not ready:raise RuntimeError('Own disposable PostgreSQL did not become ready')
    env=dict(os.environ,SMARTPLAN_TEST_DSN=f'host=127.0.0.1 port={port} dbname=smartplan_check user=postgres password=synthetic-rv-local-only',
        PYTHONPATH='.:backend:backend/business_tests:backend/online:scripts')
    tool_dir=destination/'own-pg-tools';tool_dir.mkdir(exist_ok=True)
    tool_code='''#!'''+sys.executable+'''
import json,os,sys,subprocess
from psycopg.conninfo import conninfo_to_dict,make_conninfo
args=sys.argv[1:];position=args.index('--dbname')+1
p=conninfo_to_dict(args[position]);container=os.environ['SMARTPLAN_RV_PG_CONTAINER'];port=os.environ['SMARTPLAN_RV_PG_PORT']
assert p.get('host')=='127.0.0.1' and p.get('port')==port and p['dbname'] in ('smartplan_check','smartplan_release_check','smartplan_restore_check')
info=json.loads(subprocess.check_output(['docker','inspect',container]))[0]
assert info['Id']==container and info['Config']['Labels']['smartplan.rv-lifecycle.synthetic']=='20261110'
assert info['NetworkSettings']['Ports']['5432/tcp']==[{'HostIp':'127.0.0.1','HostPort':port}]
args[position]=make_conninfo(args[position],port=5432)
tool=os.path.basename(sys.argv[0]);assert tool in ('pg_dump','pg_restore')
os.execvp('docker',['docker','exec','-i',container,tool,*args])
'''
    for name_tool in ('pg_dump','pg_restore'):
        executable=tool_dir/name_tool;executable.write_text(tool_code);executable.chmod(0o700)
    env.update(PATH=str(tool_dir)+os.pathsep+env.get('PATH',''),SMARTPLAN_RV_PG_CONTAINER=container,SMARTPLAN_RV_PG_PORT=port)
    with (destination/('postgres-'+attempt+'.txt')).open('w') as output:
        test=subprocess.run([sys.executable,'-m','unittest','-v','online.test_business_payroll_rv_lifecycle_pg'],cwd=root,env=env,
            stdout=output,stderr=subprocess.STDOUT,timeout=600)
    code=test.returncode;result['test_exit_code']=code
finally:
    original=json.loads(run('docker','inspect',container))[0]
    assert original['Id']==container and original['Name']=='/'+name and original['Config']['Labels'].get('smartplan.rv-lifecycle.synthetic')=='20261110'
    run('docker','rm','--force',container)
    result['cleanup_verified']=not run('docker','ps','--all','--quiet','--filter','id='+container)
    (destination/('postgres-'+attempt+'-environment.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
sys.exit(code)
