import json,os,subprocess,sys,tarfile,tempfile
from pathlib import Path
ROOT=Path('/workspace/Smarplan-Hofmann-Workspace')
SOURCE='3c824c174ec6247d50219a70612ba42fed75d017'
with tempfile.TemporaryDirectory(prefix='synthetic-expense-company-archive-') as directory:
    root=Path(directory);app=root/'app';app.mkdir();archive=root/'source.tar'
    subprocess.run(['git','-c','tar.umask=0022','-C',str(ROOT),'archive','--format=tar','--output',str(archive),SOURCE,'backend','web'],check=True,capture_output=True)
    with tarfile.open(archive) as source:source.extractall(app,filter='data')
    code=r'''import base64,json,sys,uuid
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from online.installation import MARKER,write_context
write_context(MARKER,sys.argv[2])
from online.test_offline_instance_binding import OfflineInstanceBindingHttpTests
f=OfflineInstanceBindingHttpTests('runTest');f.setUp()
def request(**data):return dict(request_id=uuid.uuid4().hex,**data)
try:
 receipts=[]
 for index,company in enumerate((f.a,f.b)):
  context=f.call(company,'/business/installation').json
  assert context['source_commit']==sys.argv[2]
  caps=f.call(company,'/business/capabilities').json
  assert 'personnel_expense_originals_v2' in caps['features']
  origin='https://'+company['host']
  for name in ('office.js','personnel-workflow.js'):
   response=company['client'].get('/office/'+name,base_url=origin)
   assert response.status_code==200
   assert response.data==(Path(sys.argv[1]).parent/'web/office'/name).read_bytes()
   assert b'personnel_expense_originals_v2' in response.data
  employee=f.call(company,'/business/employees',request(user_id=f.account,name='Synthetic same owner employee',weekly_minutes=2400,hourly_cost_minor=3500),status=201).json
  original=base64.b64encode(b'%PDF-1.4\nSame synthetic whole ticket across two firms\n%%EOF').decode()
  file=f.call(company,'/business/personnel/files',request(employee_id=employee['id'],purpose='expense_receipt',owner_visible=True,filename='ticket.pdf',media_type='application/pdf',content_base64=original)).json
  body=dict(employee_id=employee['id'],revision=0,purpose='Actual whole ticket',start_date='2026-11-01',end_date='2026-11-01',items=[dict(date='2026-11-01',description='Whole ticket',amount_minor=4987,currency='EUR',receipt_file_id=file['id'])])
  expense=f.call(company,'/business/personnel/expenses',request(**body)).json
  submitted=f.call(company,'/business/personnel/expenses/'+expense['id']+'/submit',request(revision=expense['revision'])).json
  assert submitted['status']=='submitted'
  duplicate=f.call(company,'/business/personnel/expenses',request(**body)).json
  f.call(company,'/business/personnel/expenses/'+duplicate['id']+'/submit',request(revision=duplicate['revision']),status=409)
  receipts.append(submitted)
 assert receipts[0]['items'][0]['receipt_sha256']==receipts[1]['items'][0]['receipt_sha256']
 f.call(f.b,'/business/capabilities',token=f.a['token'],status=401)
 print(json.dumps(dict(source_commit=sys.argv[2],actual_mfa=True,companies=2,same_original_across_companies_accepted=True,within_company_duplicate_rejected=True,cross_company_token_rejected=True,exact_archive_browser_assets=True,new_personnel_feature=True)))
finally:f.doCleanups()
'''
    result=subprocess.run([sys.executable,'-I','-B','-c',code,str(app/'backend'),SOURCE],cwd=root,
        env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME','SMARTPLAN_TEST_DSN')},capture_output=True,text=True,timeout=120)
    if result.returncode:print(result.stderr);raise SystemExit(result.returncode)
    print(result.stdout.strip())
