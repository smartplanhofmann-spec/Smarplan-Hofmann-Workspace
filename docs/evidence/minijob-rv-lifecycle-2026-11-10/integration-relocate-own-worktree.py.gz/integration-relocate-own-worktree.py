import hashlib,json,os,shutil,stat,subprocess
from pathlib import Path
old=Path('/workspace/smartplan-minijob-rv-20261110')
new=Path('/tmp/smartplan-minijob-rv-20261110')
assert old.is_dir() and not old.is_symlink() and not new.exists()
assert subprocess.check_output(['git','branch','--show-current'],cwd=old,text=True).strip()=='codex/minijob-rv-lifecycle-20261110'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=old,text=True).strip()=='4aa0abd6d313fcc5d693606dbef1c7193afb0729'
status=subprocess.check_output(['git','status','--porcelain'],cwd=old,text=True)
def manifest(root):
    result={}
    for current,dirs,files in os.walk(root,followlinks=False):
        for name in dirs+files:
            p=Path(current)/name;key=str(p.relative_to(root));mode=p.lstat().st_mode
            if stat.S_ISLNK(mode):result[key]=dict(kind='symlink',target=os.readlink(p))
            elif stat.S_ISREG(mode):result[key]=dict(kind='file',mode=stat.S_IMODE(mode),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
            elif stat.S_ISDIR(mode):result[key]=dict(kind='directory',mode=stat.S_IMODE(mode))
            else:raise RuntimeError('Unexpected special file '+key)
    return result
before=manifest(old)
shutil.copytree(old,new,symlinks=True,copy_function=shutil.copy2)
assert manifest(new)==before and manifest(old)==before
# Only this newly created task worktree is removed after the byte-verified copy.
shutil.rmtree(old)
subprocess.run(['git','worktree','repair',str(new)],cwd='/workspace/Smarplan-Hofmann-Workspace',check=True)
assert subprocess.check_output(['git','status','--porcelain'],cwd=new,text=True)==status
old.symlink_to(new,target_is_directory=True)
Path('/tmp/smartplan-minijob-rv-work-20261110/relocation-verified.json').write_text(json.dumps(dict(
    original_path=str(old),actual_worktree=str(new),entries=len(before),all_file_bytes_and_symlinks_verified=True,
    git_status_preserved=True,old_path_compatibility_symlink=True,foreign_files_deleted=False),indent=2)+'\n')
print(json.dumps(dict(actual_worktree=str(new),verified_entries=len(before),git_status_preserved=True)))
