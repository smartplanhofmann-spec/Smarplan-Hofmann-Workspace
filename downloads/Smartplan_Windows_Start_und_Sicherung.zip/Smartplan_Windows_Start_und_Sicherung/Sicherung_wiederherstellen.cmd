@echo off
call "%~dp0Run.cmd" restore
