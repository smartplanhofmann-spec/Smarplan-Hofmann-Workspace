import base64,json,os,subprocess,sys,tarfile,tempfile,unittest
from pathlib import Path
import psycopg
from psycopg.conninfo import make_conninfo
import business_schema
from business_personnel_workflow import PersonnelWorkflow,protected_tables
from online import release,test_customer_execution_journey_pg as journey
from online.store import PostgresOffice,migrate
from online.web import create_app
BASE='a93cb4d02eab610e5f2a8b07fbd1ee51ae99c3e5'
ROOT=Path('/workspace/Smarplan-Hofmann-Workspace')

@unittest.skipUnless(journey.fixture.DSN,'Own guarded disposable PostgreSQL required')
class OldPersonnelUpgrade(unittest.TestCase):
 def test_actual_previous_archive_database_migrates_with_exact_month_originals_and_payment_receipts(self):
  with tempfile.TemporaryDirectory(prefix='synthetic-old-pg-upgrade-') as directory:
   root=Path(directory);archive=root/'old.tar';old=root/'old';old.mkdir();output=root/'originals.json'
   subprocess.run(['git','-C',str(ROOT),'archive','--format=tar','--output',str(archive),BASE,'backend'],check=True,capture_output=True)
   with tarfile.open(archive) as source:source.extractall(old,filter='data')
   code='''import base64,json,sys
sys.path.insert(0,sys.argv[1])
from pathlib import Path
from online.test_business_personnel_workflow_pg import PersonnelWorkflowPostgres
f=PersonnelWorkflowPostgres('runTest');f.setUp();original=f.call;captured={}
def capture(method,path,body=None,**kwargs):
 response=original(method,path,body,**kwargs)
 if path.endswith('/reimburse'):captured.update(payment_command=body,payment_result=response.json)
 return response
f.call=capture
try:
 data=f.workflow();value=dict(actor=f.office.user(f.token),runtime=f.runtime,token=f.token,key=f.key.decode(),file=data['file'],original=base64.b64encode(data['original']).decode(),closed=data['closed'],month_command=data['command'],pdf=base64.b64encode(data['pdf']).decode(),**captured)
 Path(sys.argv[2]).write_text(json.dumps(value))
finally:f.doCleanups()
'''
   subprocess.run([sys.executable,'-I','-B','-c',code,str(old/'backend'),str(output)],cwd=root,env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME')},check=True,capture_output=True,text=True,timeout=120)
   value=json.loads(output.read_text());before=release.snapshot_fingerprint(journey.fixture.DSN)
   target=make_conninfo(journey.fixture.DSN,dbname='smartplan_release_check')
   with psycopg.connect(journey.fixture.DSN,autocommit=True) as admin:
    self.assertIsNone(admin.execute("SELECT 1 FROM pg_database WHERE datname='smartplan_release_check'").fetchone())
    admin.execute('CREATE DATABASE smartplan_release_check OWNER "smartplan-migrator" TEMPLATE template0')
   def cleanup():
    with psycopg.connect(journey.fixture.DSN,autocommit=True) as admin:admin.execute('DROP DATABASE smartplan_release_check')
   self.addCleanup(cleanup)
   report=release.prepare(journey.fixture.DSN,target,str(root/'backup'),test_mode=True,privileged_operator=True,compatibility_mode='business')
   self.assertTrue(report['privileged_operator'])
   self.assertEqual(release.snapshot_fingerprint(journey.fixture.DSN),before)
   after_migration=release.snapshot_fingerprint(target)
   for table in before:
    if table!='business_schema_migrations':self.assertEqual(after_migration[table],before[table],table)
   office=PostgresOffice(make_conninfo(value['runtime'],dbname='smartplan_release_check'))
   try:
    hr=PersonnelWorkflow(office)
    self.assertEqual(hr.expense_action(value['actor'],value['payment_result']['id'],'reimburse',value['payment_command']),value['payment_result'])
    self.assertEqual(hr.close_preparation(value['actor'],value['month_command']),value['closed'])
    self.assertEqual(hr.file_content(value['actor'],value['file']['id'])[0],base64.b64decode(value['original']))
    self.assertEqual(hr.export(value['actor'],value['closed']['id'],'pdf')[0],base64.b64decode(value['pdf']))
    business_schema.validate_integrity(office)
    client=create_app(office=office,key=value['key'].encode(),host='office.example.test',storage_config={}).test_client()
    response=client.get('/api/v1/business/capabilities',base_url='https://office.example.test',headers={'Authorization':'Bearer '+value['token']})
    self.assertEqual(response.status_code,200)
    self.assertIn('personnel_expense_originals_v2',response.json['features'])
    self.assertEqual(release.snapshot_fingerprint(journey.fixture.DSN),before)
    after=release.snapshot_fingerprint(target)
    for table in protected_tables():self.assertEqual(before[table],after[table],table)
   finally:office.db.close()

if __name__=='__main__':unittest.main()
