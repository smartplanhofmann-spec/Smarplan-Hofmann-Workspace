Smartplan Office - Offline-Pakete fuer Windows x64 / Python 3.12

1. ZIP vollstaendig entpacken (Windows: Rechtsklick, Alle extrahieren).
2. Im entpackten Ordner Installieren.cmd doppelt anklicken.
3. Nach Abschluss das Fenster mit der Erfolgsmeldung fotografieren.

Python 3.12 fuer Windows (64 Bit) muss vorhanden sein. Die Pakete werden
ausschliesslich aus dem Unterordner wheels installiert. Die Installation
benoetigt keinen Zugriff auf pypi.org oder eine andere Paketregistry.
Es werden weder TLS- noch Signatur- oder Pruefsummenpruefungen abgeschaltet.
Die Python-Umgebung liegt unter LOCALAPPDATA\SmartplanOffice\.venv,
ausserhalb des synchronisierten Projektordners.

Das Paket enthaelt die Abhaengigkeiten, nicht die gesamte Smartplan-App.
Der bereits heruntergeladene Smartplan-Quellordner bleibt unveraendert.
Flutter, Windows-Buildwerkzeuge und eine fertige EXE sind nicht enthalten.

Die enthaltenen Wheel-Dateien wurden ueber HTTPS von der offiziellen
PyPI-Registry heruntergeladen und mit deren SHA-256-Metadaten verglichen.
requirements-windows.lock erzwingt die SHA-256-Pruefung bei der Installation.
Lizenzen der Abhaengigkeiten sind in den jeweiligen Wheel-Dateien enthalten.

Pruefung in der Cloud: vollstaendige Offline-Aufloesung fuer Windows x64,
CPython 3.12. Der native Windows-Lauf kann nur auf einem Windows-PC bestaetigt
werden. Installieren.cmd fuehrt dort auch PDF- und Verschluesselungspruefungen aus.
