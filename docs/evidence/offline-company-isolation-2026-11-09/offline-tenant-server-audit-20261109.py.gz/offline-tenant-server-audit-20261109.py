"""Synthetic independent bound databases; no external network or repository writes."""
from pathlib import Path
import json
import sqlite3
import tempfile
import time
import uuid

from cryptography.fernet import Fernet
from core import Office
from online.auth import totp
from online.instance import bind
from online.storage import Storage
from online.web import create_app
from online.test_instance_isolation import MFA_SCHEMA


with tempfile.TemporaryDirectory(prefix='offline-tenant-server-audit-') as temporary:
    root = Path(temporary)
    seed = Office(root / 'seed.db')
    seed.db.executescript(MFA_SCHEMA)
    owner = {'id': seed.add_user('owner@example.test', 'Synthetic-owner-password-123', 'owner'), 'role': 'owner'}
    project = seed.add_project(owner, 'Company A project', 'Company A customer')
    # The clean seed gives distinct companies matching user/project IDs, with
    # no copied online or device tokens. Each company is bound independently.
    for name in ('a', 'b'):
        target = sqlite3.connect(root / (name + '.db'))
        seed.db.backup(target)
        target.close()
    seed.db.close()
    companies = []
    for name in ('a', 'b'):
        office = Office(root / (name + '.db'))
        if name == 'b':
            with office.db:
                office.db.execute('UPDATE projects SET name=? WHERE id=?', ('Company B project', project))
        instance = uuid.uuid4().hex
        key = Fernet.generate_key()
        host = 'same.example.test'
        storage = Storage(office, key, host, config={'server': {'path': str(root / (name + '-storage'))}})
        bind(office, instance, host, key, storage)
        client = create_app(office=office, key=key, host=host, storage=storage, instance_id=instance).test_client()

        def call(path, body=None, token=None):
            return client.open('/api/v1' + path, method='GET' if body is None else 'POST',
                base_url='https://' + host, json=body,
                headers={'Authorization': 'Bearer ' + token} if token else {})

        pending = call('/login', {'email': 'owner@example.test', 'password': 'Synthetic-owner-password-123'}).json
        token = call('/login/verify', {'challenge': pending['challenge'],
            'code': totp(pending['enrollment']['secret'], int(time.time() // 30))}).json['token']
        grant = call('/offline/access', {}, token).json['token']
        companies.append((office, client, grant, instance))

    a, b = companies
    queued = {'request_id': uuid.uuid4().hex, 'title': 'Company A confidential offline plan', 'walls': []}

    def send(company, token):
        return company[1].post('/api/v1/projects/' + project + '/plans',
            base_url='https://same.example.test', json=queued,
            headers={'Authorization': 'Bearer ' + token})

    old_at_b = send(b, a[2])
    fresh_at_b = send(b, b[2])
    own_at_a = send(a, a[2])
    result = {
        'independent_bound_instances': a[3] != b[3],
        'same_account_id': a[0].db.execute('SELECT id FROM users').fetchone()[0] == b[0].db.execute('SELECT id FROM users').fetchone()[0],
        'same_project_id': project,
        'old_A_token_at_B_status': old_at_b.status_code,
        'fresh_B_token_with_unchanged_A_command_status': fresh_at_b.status_code,
        'original_A_command_at_A_status': own_at_a.status_code,
        'B_saved_A_title': fresh_at_b.json.get('title'),
        'same_request_id': queued['request_id'],
    }
    assert result['independent_bound_instances'] and result['same_account_id']
    assert (old_at_b.status_code, fresh_at_b.status_code, own_at_a.status_code) == (401, 201, 201), result
    assert result['B_saved_A_title'] == queued['title']
    print(json.dumps(result, indent=2))
    for office, _, _, _ in companies:
        office.db.close()
