from pathlib import Path
import json
root=Path('/workspace/Smarplan-Hofmann-Workspace')
p=root/'docs/CRM_ERP_ARBEITSSTAND.md';s=p.read_text()
lines=s.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| Aktuell veröffentlichter Quell- und Testbranch |'):
  lines[i]='| Aktuell veröffentlichter Quell- und Testbranch | `abcc3510f4d913b1d4e57c30fd2e5283bce2156b`, Remote-Zeiger bestätigt. V15, Qonto und die native Offline-Konfliktklärung sind enthalten. Der neue XML-Bankimport liegt lokal geprüft vor. |'
 if line.startswith('| Eigene aktuelle Workflowprüfung |'):
  lines[i]='| Eigene aktuelle Workflowprüfung | abcc351: Development 42850956041 alle 20 Gruppen erfolgreich, eigener unsignierter iPhone-Release 206 aus 42850955774 erfolgreich. V15 an 1fa0bcc besitzt zusätzlich den tatsächlich [signierten iPhone-Release 205](CRM_ERP_IPHONE_SIGNIERTES_PAKET_205_2026-11-10.md) aus 42843099650; TestFlight-Upload false. Neue XML-Bankquellen werden separat geprüft. |'
s='\n'.join(lines)+'\n'
s=s.replace('## Aktive Arbeit: signiertes iPhone-Paket getrennt vom Upload','## Historischer Vorbereitungsabschnitt: signiertes iPhone-Paket getrennt vom Upload',1)
point='## Quellcode, Prüfstand und Installation sind getrennt'
section='''## Aktive Fertigstellung: XML-Bankoriginal und neuer Gesamtprüfstand

Der [CAMT.053.001.08-Import](CRM_ERP_BANK_CAMT_2026-11-10.md) ergänzt CSV
additiv in Backend, Browser und App. Unverändertes XML, lokales festgelegtes
Schema, unabhängige Vorschauprüfung, beide Bestätigungen und exakte Wiederholung
sind implementiert. 49 gemeinsame Fach-/Paketfälle, drei wirkliche PostgreSQL-/
MFA-/Restorefälle, alle 1.095 Browsermodule, der tatsächliche Browserablauf,
22 gemeinsame Appfälle und ein zusätzlicher tatsächlicher nativer HTTP-Ablauf
bestehen. Appanalyse ohne Probleme; vollständige neue Appprüfung läuft.
Die reale Bankdatei und direkte Bankzugänge sind damit nicht ersetzt.

Der zuvor veröffentlichte Offline-Konfliktstand abcc351 hat inzwischen alle
20 eigenen Developmentgruppen sowie seinen unsignierten iPhone-Release 206
bestanden. Der manuelle V15-Release 205 ist tatsächlich signiert; Upload false.
Die Rohmetadaten und der jeweilige genaue Quellumfang bleiben getrennt.
Nach Abschluss der lokalen Gesamtprüfung wird ausschließlich der autorisierte
Testbranch aktualisiert und sein eigener Auslieferungsnachlauf geprüft.

'''
assert point in s;s=s.replace(point,section+point,1);p.write_text(s)
entry='''
## 10.11.2026 – XML-Bankoriginal in beiden Clients und abgeschlossene ältere Pakete

Der neue additive CAMT.053.001.08-Vertrag bindet das vollständige Original,
Bankkonto, belegte Periode, Salden und Bankidentitäten. Beide Clients verlangen
zwei ausdrückliche Bestätigungen, prüfen den vollständigen Vorschauhash und
erhalten bei verlorener Antwort die identische Vorgangs-ID. Originaldownload,
frische Rechte-/Fähigkeitsprüfung und vollständiger PostgreSQL-Restore bestehen.
49 gemeinsame Fach-/Paketfälle, drei tatsächliche PG-/MFA-/Restorefälle zuletzt
in 81,839s, alle 1.095 Browsermodule, der tatsächliche Browser-Bankablauf,
22 gemeinsame Appfälle und ein zusätzlicher nativer HTTP-Ablauf sind grün.
Appanalyse ohne Probleme in 27,3s. Vollständige App-/Remoteprüfung folgt separat;
keine reale Bankanbindung oder neue Liveinstallation daraus ableiten.
Vertrag, erhaltene Erstfehler und Nachweise: CRM_ERP_BANK_CAMT_2026-11-10.md.

Der veröffentlichte Offline-Konfliktstand abcc351 besteht inzwischen alle 20
Developmentgruppen aus 42850956041 und den eigenen unsignierten iPhone-Release
206 aus 42850955774. Die separate manuelle V15-Vorbereitung 42843099650 an
1fa0bcc besteht tatsächlich einschließlich signiertem iPhone-/iPad-Paket 205,
Artefakt 13780314712; TestFlight-Upload bleibt false. Neuere Änderungen werden
nicht in diesen älteren Signiernachweis hineingelesen. Keine neue tatsächliche
Windows-/iPhone-, Fach-/Sicherheits- oder Gesamtfreigabe. R08.03, R11.06 und A–G
bleiben mit ihren konkreten Restpunkten offen. Gesamtziel unverändert erhalten.
'''
for name in ('docs/CRM_ERP_FORTSCHRITT.md','docs/CRM_ERP_UMSETZUNGSPLAN.md'):
 p=root/name;p.write_text(p.read_text()+entry)
p=root/'docs/CRM_ERP_ANFORDERUNGEN.md';lines=p.read_text().splitlines()
for i,line in enumerate(lines):
 if line.startswith('| R08.03 |'):
  lines[i]=line[:-2]+' Zusätzlich ist der [versionierte XML-Bankoriginalimport](CRM_ERP_BANK_CAMT_2026-11-10.md) für camt.053.001.08 mit beiden Clients, vollständiger Originalbindung und tatsächlichen HTTP-/PG-/Restoreprüfungen lokal integriert. Echte Kreissparkassen-Datei und direkte Anbieterzugänge fehlen weiter. |'
 if line.startswith('| R11.06 |'):
  lines[i]='| R11.06 | 11: Tatsächliche Windows-/iPhone-Installation, Updates, Gerätefunktionen und Verteilung | teilweise; Gesamtanforderung offen | Veröffentlichter Gesamtstand abcc3510f4d913b1d4e57c30fd2e5283bce2156b besteht alle 20 eigenen Development-Gruppen 42850956041 einschließlich tatsächlicher Windows-Komplett-/Onlinepakete und den eigenen unsignierten iPhone-Release 206 von 42850955774. Der ältere V15-Stand 1fa0bcc besitzt zusätzlich das tatsächlich [signierte Paket 205](CRM_ERP_IPHONE_SIGNIERTES_PAKET_205_2026-11-10.md) aus 42843099650; Upload false. Er enthält den späteren Offline-Konfliktfix und XML-Bankimport nicht. Der Nutzer bestätigt weiterhin ausschließlich den kontrollierten Serverupdate-Abschluss auf a93cb4d; kein neuer Liveupdate, kein TestFlight-Upload und keine vollständige Windows-/iPhone-Geräteabnahme. Neue XML-Bankquellen werden separat geprüft. |'
 if line.startswith('| R12.01 |'):
  lines[i]=line[:-2]+' Der additive [CAMT.053.001.08-Vertrag](CRM_ERP_BANK_CAMT_2026-11-10.md) ergänzt den Originalimport ausdrücklich begrenzt; andere Versionen oder Bankfreigaben daraus nicht ableiten. |'
p.write_text('\n'.join(lines)+'\n')
# Active operator context must not present an older top-level pointer as current.
p=Path('/tmp/smartplan-active-integration-20261109.json');v=json.loads(p.read_text())
v.update(main_head='ff78dbb',published_product='abcc3510f4d913b1d4e57c30fd2e5283bce2156b',last_remote_tip='abcc3510f4d913b1d4e57c30fd2e5283bce2156b',
 current_task='CAMT original bank import: local core, real HTTP/MFA, PG restore, browser and native passed; full native running',
 own_development_run=42850956041,own_development_successful_groups=20,
 own_unsigned_ios_run=42850955774,own_unsigned_ios_build=206,
 signed_ios=dict(source='1fa0bcceb28a822bed9600ad18e33ba54d2c227f',run=42843099650,build=205,artifact=13780314712,upload=False))
p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print('Status, requirements and actual package evidence updated; no overall completion claimed')
