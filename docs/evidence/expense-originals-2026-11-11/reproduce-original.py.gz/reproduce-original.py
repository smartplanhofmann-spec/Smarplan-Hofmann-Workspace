import base64,unittest
from core import Problem
from test_business_personnel_workflow import PersonnelWorkflowTests,rid
class CrossEmployeeReceipt( PersonnelWorkflowTests ):
    def test_same_whole_original_cannot_be_claimed_by_a_second_employee(self):
        first=self.approved_expense()
        self.hr.expense_action(self.owner,first['id'],'reimburse',dict(request_id=rid(),revision=first['revision'],amount_minor=4987,confirmed=True,paid_on='2026-10-25',payment_reference='SYN-REIMBURSED-FIRST'))
        uid=self.office.add_user('second-expense@example.test','Synthetic-second-expense-password-123','technician')
        actor=dict(id=uid,role='technician')
        self.office.assign(self.owner,self.project,uid)
        second=self.call(self.planning,'save_employee',self.owner,dict(request_id=rid(),user_id=uid,name='Synthetic second employee',weekly_minutes=2400,hourly_cost_minor=3500))
        proof=self.hr.upload(actor,dict(request_id=rid(),employee_id=second['id'],purpose='expense_receipt',owner_visible=True,filename='same-whole-ticket.pdf',media_type='application/pdf',content_base64=base64.b64encode(b'%PDF-1.4\nSynthetic personnel evidence expense\n%%EOF').decode()))
        self.assertEqual(proof['sha256'],first['items'][0]['receipt_sha256'])
        body=self.expense_body(file=proof,employee_id=second['id'])
        draft=self.hr.save_expense(actor,body)
        with self.assertRaises(Problem) as rejected:
            self.hr.expense_action(actor,draft['id'],'submit',dict(request_id=rid(),revision=draft['revision']))
        self.assertEqual(rejected.exception.status,409)
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([CrossEmployeeReceipt('test_same_whole_original_cannot_be_claimed_by_a_second_employee')]))
    raise SystemExit(not result.wasSuccessful())
